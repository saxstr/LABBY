package com.example.gp_test;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CropActivity extends AppCompatActivity {

    private ImageView cropImageView;
    private Button cropButton;
    private Button cancelButton;
    private Bitmap originalBitmap;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);

        // Link views from XML
        cropImageView = findViewById(R.id.cropImageView);
        cropButton = findViewById(R.id.cropButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Get the bitmap passed from the previous activity
        try {
            originalBitmap = getIntent().getParcelableExtra("imageBitmap");
            if (originalBitmap != null) {
                cropImageView.setImageBitmap(originalBitmap);
            } else {
                throw new Exception("No image received for cropping.");
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error loading image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
        }

        // Crop button functionality
        cropButton.setOnClickListener(v -> {
            try {
                Bitmap croppedBitmap = cropImage();
                if (croppedBitmap != null) {
                    // Pass cropped image back to the galleryFragment
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("croppedBitmap", croppedBitmap);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    throw new Exception("Failed to crop image.");
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error during cropping: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // Cancel button functionality
        cancelButton.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }

    private Bitmap cropImage() {
        try {
            // Example crop logic: crop a square from the center of the image
            int width = originalBitmap.getWidth();
            int height = originalBitmap.getHeight();
            int newWidth = Math.min(width, height); // Crop square
            int newHeight = newWidth;
            int cropStartX = (width - newWidth) / 2;
            int cropStartY = (height - newHeight) / 2;

            return Bitmap.createBitmap(originalBitmap, cropStartX, cropStartY, newWidth, newHeight);
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, "Cropping failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return null;
        }
    }
}
