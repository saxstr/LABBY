package com.example.gp_test;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** @noinspection deprecation*/
public class galleryFragment extends Fragment {

    private ImageView capturedImageView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tutorialpage_sc, container, false);

        capturedImageView = view.findViewById(R.id.capturedImageView);
        Button openCameraButton = view.findViewById(R.id.openCameraButton);

        // Set button click listener
        openCameraButton.setOnClickListener(v -> openCamera());

        return view;
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(takePictureIntent, 1);
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 101);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 101 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            Toast.makeText(requireContext(), "Camera permission is required to use this feature.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == AppCompatActivity.RESULT_OK) {
            if (requestCode == 1 && data != null) {
                Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
                if (imageBitmap != null) {
                    Uri sourceUri = saveBitmapToCache(imageBitmap);

                    // Start UCrop for cropping
                    cropImage(sourceUri);
                }
            } else if (requestCode == UCrop.REQUEST_CROP && data != null) {
                try {
                    Uri resultUri = UCrop.getOutput(data);
                    if (resultUri != null) {
                        Bitmap croppedBitmap = MediaStore.Images.Media.getBitmap(requireContext().getContentResolver(), resultUri);

                        // Pass cropped image for OCR processing
                        processImageWithOCR(croppedBitmap);
                    }
                } catch (IOException e) {
                    Toast.makeText(requireContext(), "Error retrieving cropped image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == UCrop.RESULT_ERROR) {
                Throwable cropError = UCrop.getError(data);
                Toast.makeText(requireContext(), "Crop error: " + (cropError != null ? cropError.getMessage() : "Unknown error"), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void cropImage(Uri sourceUri) {
        Uri destinationUri = Uri.fromFile(new File(requireContext().getCacheDir(), "croppedImage.jpg"));

        UCrop.of(sourceUri, destinationUri)
                .withAspectRatio(1, 1) // Set cropping aspect ratio (square by default)
                .withMaxResultSize(1080, 1080) // Set max size for the output image
                .withOptions(getUCropOptions())
                .start(requireContext(), this); // Start UCrop
    }

    private UCrop.Options getUCropOptions() {
        UCrop.Options options = new UCrop.Options();
        options.setCompressionQuality(100); // Set highest image quality
        options.setFreeStyleCropEnabled(true); // Enable freestyle cropping
        options.setToolbarTitle("Crop Image"); // Toolbar title
        options.setToolbarColor(ContextCompat.getColor(requireContext(), R.color.primary));
        options.setStatusBarColor(ContextCompat.getColor(requireContext(), R.color.primary_dark));
        options.setActiveControlsWidgetColor(ContextCompat.getColor(requireContext(), R.color.accent)); // Corrected method name
        return options;
    }


    private Uri saveBitmapToCache(Bitmap bitmap) {
        try {
            File cacheFile = new File(requireContext().getCacheDir(), "tempImage.jpg");
            FileOutputStream out = new FileOutputStream(cacheFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out); // Save bitmap as JPEG with high quality
            out.flush();
            out.close();
            return Uri.fromFile(cacheFile);
        } catch (IOException e) {
            Toast.makeText(requireContext(), "Error saving image to cache: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void processImageWithOCR(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    StringBuilder recognizedText = new StringBuilder();
                    for (Text.TextBlock block : result.getTextBlocks()) {
                        recognizedText.append(block.getText()).append("\n");
                    }

                    // Pass recognized text to TestResultSc activity
                    Intent intent = new Intent(requireContext(), TestResultSc.class);
                    intent.putExtra("recognizedText", recognizedText.toString());
                    startActivity(intent);
                })
                .addOnFailureListener(e -> Toast.makeText(requireContext(), "OCR Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
